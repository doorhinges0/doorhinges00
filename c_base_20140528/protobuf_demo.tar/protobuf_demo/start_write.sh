
g++ -opbread addressbook.pb.cc addressbook_test.cpp -L/usr/local/lib/ -lprotobuf 

