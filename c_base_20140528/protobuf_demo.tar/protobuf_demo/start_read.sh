
g++ -opbwrite  addressbook.pb.cc addressbook_list.cpp  -L/usr/local/lib/ -lprotobuf 

